#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdint.h>
#include <signal.h>
#include <csse2310a3.h>
#define PARALLELARG "--parallel"
#define OUTPUTARG "--output"
#define EXTRACTARG "--extract"
#define BZIP2ARG "--bzip2"
#define GZIPARG "--gzip"
#define ZIPARG "--zip"
#define XZARG "--xz"
#define NONEARG "--none"
#define DEFAULTFILENAME "out.uqz"
#define FILE_PERMISSIONS 0666
bool sigintOccurred = false;
const char* const nonemethod[] = {"cat", NULL};
const char* const bzip2method[] = {"bzip2", "--stdout", NULL};
const char* const gzipmethod[] = {"gzip", "-n", "--best", "--stdout", NULL};
const char* const xzmethod[] = {"xz", "--stdout", NULL};
const char* const zipmethod[] = {"zip", "-DXj", "-fz-", "-", NULL};
const char* const decompressmethod[][5]
        = {{"cat", NULL}, {"bzip2", "-dc", NULL}, {"gzip", "-dc", NULL},
                {"xz", "-dc", NULL}, {"funzip", NULL}};

// Structure to hold information about a valid set of command line arguments
typedef struct {
    bool parallel;
    bool output;
    bool extract;
    bool bzip2;
    bool gzip;
    bool zip;
    bool xz;
    bool none;
    uint8_t methodnum;
    uint32_t numFiles;
    char** filenames;
    char* uqzipFileName;
    const char* const* compressionmethod;
} Parameters;

typedef struct {
    uint32_t numfiles;
    uint32_t* datalength;
    uint8_t* filenamelength;
    char** filebasenames;
    char* zipfilename;
    int* padding;
    int* offset;
    int filescompressed;
} CompressionData;

typedef struct {
    uint32_t* datalength;
    uint8_t* filenamelength;
    char** filename;
    bool parallel;
} FileInfo;

// enum holding the compression method numbers of arguments
typedef enum {
    NONE = 1,
    BZIP2 = 2,
    GZIP = 3,
    XZ = 4,
    ZIP = 5,
} Parametervariables;

// enum holding exit codes
typedef enum {
    COMMANDLINE_ERROR = 16,
    ZIPWRITE_ERROR = 17,
    ZIPREAD_ERROR = 9,
    SIGINT_ERROR = 20,
    FORMAT_ERROR = 1,
    SUCCESS_EXIT = 0,
    COMMAND_ERROR = 19,
    COMMAND_FILE_ERROR = 15,
} ExitCodes;

typedef enum {
    BUFFER_SIZE = 1024,
    HEADER_BYTES = 8,
    FILERECORD_BYTES = 5,
    PADDING_FACTOR = 4,
    UQZ_SIGNATURE = 3,
} ByteSizes;

///////////////////////////////////////////////////////
Parameters process_command_line(int argc, char** argv);
void usage_error();
void compress(Parameters params);
void file_check_compression(char* zipfilename);
void initialise_zip(Parameters params);
Parameters populate_parameters(int argc, char** argv);
Parameters set_default_parameters();
Parameters process_command_line(int argc, char** argv);
void decompress(Parameters params);
void file_check_decompression(char* zipfilename);
void sequential_compression(Parameters params);
char* compression_method(int methodnum);
char** file_basenames(char** filenames, int numfiles);
CompressionData initialise_compressdata(Parameters params);
uint8_t* string_array_lengths(char** strings, int numfiles);
CompressionData sequential_file_data(
        Parameters params, CompressionData compressdata);
char** get_method_arguments(const char* const method[], char* filename);
void update_header(CompressionData compressdata, Parameters params);
int write_padding(int zipfd, int filenamelength, int datalength);
void update_data_length(int zipfd, uint8_t basenamelength, uint32_t datalength);
void suppress_stderr();
void initialise_file_record(int zipfd, uint8_t filenamelength, char* filename);
void status_check(int status, Parameters params, CompressionData compressdata,
        int filenum);
void parallel_compression(Parameters params);
CompressionData parallel_file_data(
        Parameters params, CompressionData compressdata);
int** create_pipes(int numpipes);
void close_all_writing(int** fds, int numfds);
char*** create_args_list(
        const char* const method[], char** filenames, int numfiles);
FileInfo initialise_fileinfo(
        FILE* file, UqzHeaderSection header, Parameters params);
void sequential_decompress(FILE* file, UqzHeaderSection header,
        FileInfo fileinfo, char* zipfilename);
void status_check_decompression(
        int status, char** args, FileInfo fileinfo, int filenum, int print);
void close_all_reading(int** fds, int numfds);
void parallel_decompress(FILE* file, UqzHeaderSection header, FileInfo fileinfo,
        char* zipfilename);
void kill_all_children(pid_t children[], int numchildren, int currentchild);
int format_check(FILE* file, UqzHeaderSection header, FileInfo fileinfo,
        char* zipfile, int currentfile);
void format_error(char* zipfile);
void remove_made_files(char** filenames, int numfiles, int currentfile);
void parallel_child_process(int* fds, char** args);
void parallel_write_child(
        int filefd, int** fds, int numfiles, int currentfile, char** args);
void parallel_read_child(int filefd, int** fds, int numfiles, int i,
        int datalength, FILE* file, UqzHeaderSection header, FileInfo fileinfo);

///////////////////////////////////////////////////////

/* notice()
 * --------
 * 	Method responds to a SIGINT signal by setting sigintOccurred to true.
 */
void notice()
{
    sigintOccurred = true;
}

int main(int argc, char** argv)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = notice;
    sa.sa_flags = SA_RESTART;
    sigaction(SIGINT, &sa, 0);

    Parameters params = process_command_line(argc, argv);
    if (params.extract) {
        decompress(params); // Decompress the current file
    } else {
        compress(params); // Compress the current file
    }

    return 0;
}

/* sigint_error()
 * --------------
 * 	When method is called, a sigint error message is printed
 * 	with appropriate error message.
 *
 */
void sigint_error()
{
    fprintf(stderr, "uqzip: Execution interrupted\n");
    exit(SIGINT_ERROR); // Exit with status 20
}

/* process_command_line()
 * ----------------------
 * 	Iterates through the Parameters struct returned by populate_parameters()
 * with parameters (argc, argv) validating all arguments. If an arguments is
 * found to be invalid, it calls the usage_error(), else, it returns the valid
 * Parameters struct.
 *
 * 	argc: An integer containing the number of elements in argv.
 * 	argv: An array of strings representing the command line arguments.
 *
 * 	returns: Returns a valid struct of Parameters, or if the arguments
 * 	are invalid, usage_error() is called.
 */
Parameters process_command_line(int argc, char** argv)
{
    // Check that the command line is not empty
    if (argc == 0) {
        usage_error();
    }
    Parameters params = populate_parameters(argc, argv);
    // Set the argument to none if not specified
    if (!params.bzip2 && !params.gzip && !params.zip && !params.xz
            && !params.none && !params.extract) {
        params.none = true;
    }

    if (params.output && strcmp(params.uqzipFileName, "") == 0) {
        usage_error();
    }
    // Check if more than one compression argument is given
    if (params.bzip2 + params.gzip + params.zip + params.xz + params.none > 1) {
        usage_error();
    }
    // Check that --extract and any zip argument are not both given
    if (params.extract
            && (params.bzip2 + params.gzip + params.zip + params.xz
                            + params.none
                    == 1)) {
        usage_error();
    }
    // Check that --output and --extract are not both given
    if (params.output && params.extract) {
        usage_error();
    }
    if (params.extract && (params.numFiles > 1)) {
        usage_error();
    }
    return params;
}

/* populate_parameters()
 * ---------------------
 * 	Method iterates through argv (the command line arguments) and populates
 * 	a Parameters struct with the present arguments.
 *
 *      argc: An integer containing the number of elements in argv.
 *      argv: An array of strings representing the command line arguments.
 *
 * 	returns: A Parameters struct with present command line arguments. If an
 * 	argument is found to not satisfy parameter in the struct, usage_error()
 * 	is thrown.
 */
Parameters populate_parameters(int argc, char** argv)
{
    Parameters params = set_default_parameters();
    // Skip over program name
    argc--, argv++;
    while (argv[0] && strncmp(argv[0], "--", 2) == 0) {
        // Current argument begins with "--"
        if (!strcmp(argv[0], PARALLELARG) && !params.parallel) {
            params.parallel = true;
        } else if (!strcmp(argv[0], OUTPUTARG) && !params.output) {
            params.output = true;
            params.uqzipFileName = argv[1];
            argc--, argv++;
        } else if (!strcmp(argv[0], EXTRACTARG) && !params.extract) {
            params.extract = true;
        } else if (!strcmp(argv[0], BZIP2ARG) && !params.bzip2) {
            params.bzip2 = true, params.methodnum = BZIP2,
            params.compressionmethod = bzip2method;
        } else if (!strcmp(argv[0], GZIPARG) && !params.gzip) {
            params.gzip = true, params.methodnum = GZIP,
            params.compressionmethod = gzipmethod;
        } else if (!strcmp(argv[0], ZIPARG) && !params.zip) {
            params.zip = true, params.methodnum = ZIP,
            params.compressionmethod = zipmethod;
        } else if (!strcmp(argv[0], XZARG) && !params.xz) {
            params.xz = true, params.methodnum = XZ,
            params.compressionmethod = xzmethod;
        } else if (!strcmp(argv[0], NONEARG) && !params.none) {
            params.none = true, params.methodnum = NONE;
        } else {
            usage_error();
        }
        // Skip one argument
        argc--, argv++;
    }
    // All remaining arguments (if any) are filenames.
    params.numFiles = argc;
    params.filenames = argv;

    if (params.numFiles == 0) {
        usage_error();
    }
    // Make sure filenames are not empty strings
    while (*argv) {
        if (!argv[0][0]) {
            usage_error();
        }
        argv++;
    }
    return params;
}

/* set_default_parameters()
 * ------------------------
 * 	Method creates a default Parameters struct.
 *
 * 	returns: An initialised Parameters struct.
 */
Parameters set_default_parameters()
{
    Parameters params = {
            .parallel = false,
            .output = false,
            .extract = false,
            .bzip2 = false,
            .gzip = false,
            .zip = false,
            .xz = false,
            .none = false,
            .methodnum = 1,
            .numFiles = 0,
            .filenames = NULL,
            .uqzipFileName = DEFAULTFILENAME,
            .compressionmethod = nonemethod,
    };
    return params;
}

/* usage_error()
 * -------------
 * 	When called, method prints a commandline arguments
 * 	error message and returns with appropriate exit status.
 */
void usage_error()
{
    fprintf(stderr,
            "Usage: ./uqzip [--parallel] [--output outputFileName] "
            "[--bzip2|--gzip|--zip|--xz|--none] fileName ...\n");
    fprintf(stderr, "   Or: ./uqzip --extract [--parallel] uqz-file\n");
    exit(COMMANDLINE_ERROR);
}

/* file_check_decompression()
 * --------------------------
 *      Method checks that a given zipfilename is a valid uqzipfile,
 *      if it is invalid, relevent error statements are printed and the
 *      program exits.
 *
 *      zipfilename: A string representing the intended uqzipfile name.
 */
void file_check_decompression(char* zipfilename)
{

    if (open(&(zipfilename[0]), O_RDONLY) == -1) {
        fprintf(stderr, "uqzip: can't read from file \"%s\"\n", zipfilename);
        exit(ZIPREAD_ERROR);
    }
}

/* decompress()
 * ----------
 *      Method controls the appropriate decompression of the uqzip file. Given
 *      the Parameters struct, decompress() calls the sequential
 *      or parallel compression.
 *
 *      params: A Parameters struct containing relevent information about the
 *      command line arguments.
 *
 */
void decompress(Parameters params)
{
    char* zipfile = params.filenames[0];
    file_check_decompression(zipfile);
    FILE* file = fopen(zipfile, "r");
    UqzHeaderSection* header = read_uqz_header_section(file);
    if (header == NULL) {

        format_error(zipfile);
    }
    FileInfo fileinfo = initialise_fileinfo(file, *header, params);
    if (params.parallel) {
        parallel_decompress(file, *header, fileinfo, zipfile);
    } else {
        sequential_decompress(file, *header, fileinfo, zipfile);
    }
}

/* format_error()
 * --------------
 * 	When called, method prints file format message and exits
 * 	with appropriate error code.
 */
void format_error(char* zipfilename)
{
    fprintf(stderr,
            "uqzip: Archive file \"%s\" does not have the correct format\n",
            zipfilename);
    exit(FORMAT_ERROR);
}

/* parallel_decompress()
 * ---------------------
 * 	Method controls appropriate sequencing of parallel decompression in
 * 	order to correctly extract files from a given zip file (FILE* file)
 * 	with appropriate error handling.
 *
 * 	file: A file pointer relating to the uqzip file to be decompressed.
 * 	header: The UqzHeaderSection struct of the given uqzip file.
 * 	fileinfo: A struct with appropriate information about the file
 * 	records within the uqzip file.
 * 	zipfilename: The uqzip file name.
 */
void parallel_decompress(FILE* file, UqzHeaderSection header, FileInfo fileinfo,
        char* zipfilename)
{
    int numfiles = header.numFiles;
    int** fds = create_pipes(numfiles);
    pid_t writeChild[numfiles];
    pid_t readChild[numfiles];
    char** args
            = get_method_arguments(decompressmethod[header.method - 1], NULL);
    int zipid = fileno(file);
    int status;
    int readfiles = 0;
    for (int i = 0; i < numfiles; i++) {
        int filefd = format_check(file, header, fileinfo, zipfilename, i);
        if (filefd == -1) {
            kill_all_children(writeChild, readfiles, i + 1);
            remove_made_files(fileinfo.filename, readfiles, i);
            format_error(zipfilename);
        }
        int datalength = fileinfo.datalength[i];
        readfiles++;
        writeChild[i] = fork();
        if (writeChild[i] == 0) {

            parallel_write_child(filefd, fds, numfiles, i, args);
        } else {
            readChild[i] = fork();

            if (readChild[i] == 0) {
                parallel_read_child(filefd, fds, numfiles, i, datalength, file,
                        header, fileinfo);
            }
        }
    }
    close_all_writing(fds, numfiles);
    close_all_reading(fds, numfiles);
    for (int i = 0; i < readfiles; i++) {
        waitpid(readChild[i], &status, 0);
    }

    for (int i = 0; i < readfiles; i++) {
        waitpid(writeChild[i], &status, 0);
        if (WTERMSIG(status) == SIGUSR1) {
            kill_all_children(writeChild, readfiles, i + 1);
            remove_made_files(fileinfo.filename, readfiles, i);
        }
        status_check_decompression(status, args, fileinfo, i, 0);
    }
    close(zipid);
}

void parallel_read_child(int filefd, int** fds, int numfiles, int i,
        int datalength, FILE* file, UqzHeaderSection header, FileInfo fileinfo)
{
    close_all_reading(fds, numfiles);
    close(filefd);
    char* buffer = malloc(sizeof(char) * datalength);

    fseek(file,
            header.fileRecordOffsets[i] + FILERECORD_BYTES
                    + fileinfo.filenamelength[i],
            SEEK_SET);
    fread(buffer, sizeof(char), datalength, file);

    write(fds[i][1], buffer, datalength);

    close_all_writing(fds, numfiles);
    free(buffer);

    exit(SUCCESS_EXIT);
}

/* parallel_write_child()
 * ---------------------------
 * 	Method controls the behaviour of a given fds (currentfile) within the
 * 	fds list such appropriate piping occurs for the parallel decompression
 * 	case. Although not enforced, it is assumed that the method will only be
 * 	called within the child process being targeted.
 *
 * 	filefd: The file descriptor of the output file.
 * 	fds: A list of pipe inputs and outputs for each file.
 * 	numfiles: The number of files (fds) to possibly be evaluated.
 * 	currentfile: The number of the file currently being evaluated.
 * 	args: A list of strings representing the argument to be executed
 * 	within execvp().
 */
void parallel_write_child(
        int filefd, int** fds, int numfiles, int currentfile, char** args)
{
    close_all_writing(fds, numfiles);
    suppress_stderr();
    dup2(fds[currentfile][0], STDIN_FILENO);
    dup2(filefd, STDOUT_FILENO);
    close(filefd);
    close_all_reading(fds, numfiles);
    execvp(args[0], args);
    kill(getpid(), SIGUSR1);
}

/* remove_made_files()
 * -------------------
 * 	Removes all files in filenames between currentfile and numfiles
 * 	from current directory. It is important to note that the method
 * 	does no check if the file exists.
 *
 * 	filenames: A list of strings representing all the file names to
 * 	potentially remove.
 * 	numfiles: The number of filenames within filenames.
 * 	currentfile: The number file from which to start removing.
 */
void remove_made_files(char** filenames, int numfiles, int currentfile)
{
    for (int i = currentfile; i < numfiles; i++) {
        remove(filenames[i]);
    }
}

/* kill_all_children()
 * -------------------
 * 	Method kills all children within children[] between currentchildren
 * 	and numchildren.
 *
 * 	children[] = A list of pid_t corresponding to each child pid.
 * 	numchildren = The number of children in children[].
 * 	currentchild = The child from which to start killing
 *
 */
void kill_all_children(pid_t children[], int numchildren, int currentchild)
{
    int status;
    for (int i = currentchild; i < numchildren; i++) {
        kill(children[i], SIGTERM);
        waitpid(children[i], &status, 0);
    }
}

/* initialise_fileinfo()
 * ---------------------
 * 	Method creates and returns an initialised FileInfo struct populated
 * 	with filename lengths, data lengths and filenames found using header.
 *
 * 	file: The file pointer of the open uqzip file.
 * 	header: The UqzHeaderSection of the given uqzip file.
 *
 * 	returns: A FileInfo struct with relevent file names and lengths and data
 * 	lengths.
 */
FileInfo initialise_fileinfo(
        FILE* file, UqzHeaderSection header, Parameters params)
{
    int numfiles = header.numFiles;
    uint8_t* filenamelength = malloc(sizeof(uint8_t) * numfiles);
    uint32_t* datalengths = malloc(sizeof(uint32_t) * numfiles);
    char** filename = malloc(sizeof(char*) * numfiles);

    uint32_t* offsets = header.fileRecordOffsets;

    for (int i = 0; i < numfiles; i++) {
        fseek(file, offsets[i], SEEK_SET);

        fread(&(datalengths[i]), sizeof(uint32_t), 1, file);

        fread(&(filenamelength[i]), sizeof(uint8_t), 1, file);
        filename[i] = malloc(sizeof(char) * (filenamelength[i]));

        fread(filename[i], sizeof(char), filenamelength[i], file);
        filename[i][filenamelength[i]] = '\0';
    }

    FileInfo fileinfo = {
            .filenamelength = filenamelength,
            .datalength = datalengths,
            .filename = filename,
            .parallel = params.parallel,
    };
    return fileinfo;
}

/* format_check()
 * --------------
 * 	Method checks that a given file record (currentfile) within
 * 	the uqzip file (FILE* file) is valid in size and contents, such
 * 	that its contents match that found within fileinfo and the header.
 *
 * 	file: A file pointer relating to the uqzip file to be decompressed.
 *      header: The UqzHeaderSection struct of the given uqzip file.
 *      fileinfo: A struct with appropriate information about the file
 *      records within the uqzip file.
 *      zipfilename: The uqzip file name.
 *
 *      returns: Method either returns the valid fileid, however, if the file
 *      is invalid and sequential decompression is specified, then
 *      format_error() is thrown. If parallel is specified, an invalid
 *      file record will result in the method returing -1.
 */
int format_check(FILE* file, UqzHeaderSection header, FileInfo fileinfo,
        char* zipfilename, int currentfile)
{
    char* filename = fileinfo.filename[currentfile];
    int filenamelength = fileinfo.filenamelength[currentfile];
    int datalength = fileinfo.datalength[currentfile];
    uint32_t offset = header.fileRecordOffsets[currentfile];
    bool parallel = fileinfo.parallel;
    fseek(file, offset + FILERECORD_BYTES, SEEK_SET);
    char buffer[datalength + filenamelength];
    if (((int)fread(buffer, sizeof(char), filenamelength, file)
                != filenamelength)
            || (filenamelength <= 0)) {
        if (parallel) {
            return -1;
        }
        remove(filename);

        format_error(zipfilename);
    }
    if ((int)fread(buffer, sizeof(char), datalength, file) != datalength) {
        if (parallel) {
            return -1;
        }
        remove(filename);
        format_error(zipfilename);
    }
    int filefd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, FILE_PERMISSIONS);
    if (filefd == -1) {
        fprintf(stderr, "uqzip: can't write to file \"%s\"\n", filename);
        // remove(filename);
        exit(ZIPWRITE_ERROR);
    }
    return filefd;
}

/* sequential_decompress()
 * -----------------------
 *      Method controls the order of operations to sequentially unzip a
 *      given uqzip file for a given set of params, fileinfo, header and
 *      file uqzip pointer.
 *
 *      file: The file pointer of the open uqzip file.
 *      header: The UqzHeaderSection of the given uqzip file.
 *      params: A Parameters struct containing relevent information about the
 *      command line arguments.
 *      fileinfo:  A FileInfo struct with relevent file names and lengths and
 * data lengths.
 */
void sequential_decompress(FILE* file, UqzHeaderSection header,
        FileInfo fileinfo, char* zipfilename)
{
    int numfiles = header.numFiles;
    char** args = (char**)decompressmethod[header.method - 1];
    for (int i = 0; i < numfiles; i++) {
        while (!sigintOccurred) {
            int fileid = format_check(file, header, fileinfo, zipfilename, i);
            int datalength = fileinfo.datalength[i];
            int fd[2];
            pipe(fd);
            pid_t pid = fork();
            if (pid == 0) { // Child process
                close(fd[1]); // Close the write end of the pipe in the child
                suppress_stderr();
                dup2(fd[0], STDIN_FILENO); // Redirect pipe to stdin
                close(fd[0]);
                dup2(fileid, STDOUT_FILENO); // Redirect output to file
                close(fileid);
                execvp(args[0], args); // Execute decompression command
                kill(getpid(), SIGUSR1); // If execvp fails, send SIGUSR1
            } else { // Parent process
                close(fd[0]); // Close the read end of the pipe in the parent
                char buffer[datalength];
                // Read data for the current file from the archive and write to
                // the pipe
                fseek(file,
                        header.fileRecordOffsets[i] + FILERECORD_BYTES
                                + fileinfo.filenamelength[i],
                        SEEK_SET);
                fread(buffer, 1, datalength, file);

                write(fd[1], buffer, datalength);
                fflush(file);
                close(fd[1]); // Close the write end of the pipe to signal EOF
                              // to child

                int status;
                waitpid(pid, &status, 0); // Wait for child process to finish
                status_check_decompression(status, args, fileinfo, i,
                        1); // Check the status of the decompression
            }
            close(fileid);
            break;
        }
    }
}

/* status_check_decompression()
 * ----------------------------
 *      status: An integer corresponding to the signal to be evaluated.
 *      args: The command line argument executed.
 *      params: A Parameters struct containing relevent information about the
 *      command line arguments.
 *      fileinfo:  A FileInfo struct with relevent file names and lengths and
 * data lengths.
 *      print: Bool-like integer representing whether to print the error
 * messages or not.
 */
void status_check_decompression(
        int status, char** args, FileInfo fileinfo, int filenum, int print)
{
    char* command = args[0];

    char* filename = fileinfo.filename[filenum];

    // Check if child terminated with SIGUSR1 (command execution failure)
    if (WIFSIGNALED(status) && WTERMSIG(status) == SIGUSR1) {
        fprintf(stderr, "uqzip: Can't execute command \"%s\"\n", command);
        remove(filename);
        exit(COMMAND_ERROR);
    }

    // Check if child process failed for any other reason (non-zero exit status)
    if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
        fprintf(stderr, "uqzip: Command \"%s\" failed for filename \"%s\"\n",
                command, filename);
        remove(filename);
        exit(COMMAND_FILE_ERROR);
    }

    // If successfully extracted, print success message
    if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
        if (print) {
            printf("\"%s\" has been extracted successfully\n", filename);
        }
    }
}

/* compress()
 * ----------
 * 	Method controls the appropriate construction of the uqzip file. Given
 * 	the Parameters struct, compress() controls calls the sequential
 * 	or parallel compression.
 *
 * 	params: A Parameters struct containing relevent information about the
 * 	command line arguments.
 *
 */
void compress(Parameters params)
{
    char* zipfilename = params.uqzipFileName;
    file_check_compression(zipfilename);
    initialise_zip(params);
    if (params.parallel) {
        parallel_compression(params);
    } else {
        sequential_compression(params);
    }
}

/* parallel_compression()
 * ----------------------
 *      Method controls the order of operations to construct
 *      a uqzip file for a given set of parameters (params) in parallel.
 *
 *      params: A Parameters struct containing relevent information about the
 *      command line arguments.
 */
void parallel_compression(Parameters params)
{
    CompressionData compressdata = initialise_compressdata(params);
    compressdata = parallel_file_data(params, compressdata);
    update_header(compressdata, params);
    if (compressdata.filescompressed < (int)compressdata.numfiles) {
        remove(params.uqzipFileName);
        sigint_error();
    }
}

/* parallel_file_data()
 * ----------------------
 *      Method creates children to be parasited with a execvp() call in
 * parallel. The output of execvp() (stdout) for each file to be compressed is
 * redirected to a pipe which the parent directly writes to the given uqzipfile.
 * The method then completes the each file record and catches any error given by
 * a child.
 *
 *      params: A Parameters struct detailing the command line arguments.
 *      compressdata: A incomplete CompressionData struct which initially
 * 	contains information limited to the information in params.
 *
 *      returns: Returns a CompressionData struct with completed all information
 * 	about each file record.
 */
CompressionData parallel_file_data(
        Parameters params, CompressionData compressdata)
{
    int numfiles = (int)params.numFiles;
    int** fds = create_pipes(numfiles);
    pid_t pid[numfiles];
    char*** arglist = create_args_list(
            params.compressionmethod, params.filenames, numfiles);
    int zipfd = open(params.uqzipFileName, O_WRONLY, FILE_PERMISSIONS);
    for (int i = 0; i < numfiles; i++) {
        while (!sigintOccurred) {
            compressdata.filescompressed++;
            char** args = arglist[i];
            pid[i] = fork();
            if (pid[i] == 0) {
                parallel_child_process(fds[i], args);
            }
            break;
        }
    }
    for (int i = 0; i < numfiles; i++) {
        while (!sigintOccurred) {
            uint32_t datalength = 0;
            if (pid[i]) {
                close_all_writing(fds, numfiles);
                compressdata.offset[i] = lseek(zipfd, 0, SEEK_END);
                initialise_file_record(zipfd, compressdata.filenamelength[i],
                        compressdata.filebasenames[i]);
                char buffer[BUFFER_SIZE];
                int bytesRead = 0;
                while ((bytesRead = read(fds[i][0], buffer, sizeof(buffer)))
                        > 0) {
                    lseek(zipfd, 0, SEEK_END);
                    write(zipfd, buffer, bytesRead);
                    datalength += bytesRead;
                }
                compressdata.datalength[i] = datalength;
                update_data_length(zipfd, compressdata.filenamelength[i],
                        compressdata.datalength[i]);
                compressdata.padding[i] = write_padding(
                        zipfd, compressdata.filenamelength[i], datalength);
                int status;
                waitpid(pid[i], &status, 0);
                status_check(status, params, compressdata, i);
                close(fds[i][0]);
            }
            break;
        }
    }
    close(zipfd);
    free(arglist);
    return compressdata;
}

/* parallel_child_process()
 * ------------------------
 * 	Method controls the functions of a child process within
 * 	the method it was called from.
 *
 * 	fds: A pipe for which the process communicates.
 * 	args: An array of strings representing the arguments for
 * 	execvp() to run.
 *
 */
void parallel_child_process(int* fds, char** args)
{
    suppress_stderr();
    dup2(fds[1], STDOUT_FILENO);
    close(fds[1]);
    close(fds[0]);
    execvp(args[0], args);
    kill(getpid(), SIGUSR1);
}

/* create_args_list()
 * ------------------
 * 	Creates and returns a list of lists, with each entry corresponding
 * 	to the comman line executable to be processed by execvp().
 *
 * 	method: An array of arguments onto which to append a filename
 * 	and place in an entry of the list of lists.
 * 	filesnames: A list of filenames for all lists to be constructed.
 * 	numfiles: The number of files for which to create lists.
 */
char*** create_args_list(
        const char* const method[], char** filenames, int numfiles)
{
    char*** argslist = malloc(sizeof(char**) * numfiles);
    for (int i = 0; i < numfiles; i++) {
        argslist[i] = get_method_arguments(method, filenames[i]);
    }
    return argslist;
}

/* close_all_writing()
 * -------------------
 * 	Closes all writing ends of the list of fds specified within a process.
 *
 * 	fds: A list of fds for which to close the writing ends.
 * 	numfds: The number of fds as an integer.
 */
void close_all_writing(int** fds, int numfds)
{
    for (int i = 0; i < numfds; i++) {
        close(fds[i][1]);
    }
}

/* close_all_reading()
 * -------------------
 *      Closes all reading ends of the list of fds specified within a process.
 *
 *      fds: A list of fds for which to close the reading ends.
 *      numfds: The number of fds as an integer.
 */
void close_all_reading(int** fds, int numfds)
{
    for (int i = 0; i < numfds; i++) {
        close(fds[i][0]);
    }
}

/* create_pipes()
 * --------------
 * 	Creates a list of pipes for the process from which it was called.
 *
 * 	numpipes: The number of pipes to be created as a integer.
 *
 * 	returns: A list of integer lists representing each pipe.
 */
int** create_pipes(int numpipes)
{
    int** fds = malloc(sizeof(int*) * numpipes);
    for (int i = 0; i < numpipes; i++) {
        fds[i] = malloc(sizeof(int) * 2);
        pipe(fds[i]);
    }
    return fds;
}

/* sequential_compression()
 * ------------------------
 * 	Method controls the order of operations to sequentially construct
 * 	a uqzip file for a given set of parameters (params).
 *
 * 	params: A Parameters struct containing relevent information about the
 *      command line arguments.
 */
void sequential_compression(Parameters params)
{
    CompressionData compressdata = initialise_compressdata(params);
    compressdata = sequential_file_data(params, compressdata);
    update_header(compressdata, params);
    if (compressdata.filescompressed < (int)compressdata.numfiles) {
        remove(params.uqzipFileName);
        sigint_error();
    }
}

/* sequential_file_data()
 * ----------------------
 * 	Method sequentially creates children to be parasited with a execvp()
 * call. The output of execvp() (stdout) for each file to be compressed is
 * redirected to a pipe which the parent directly writes to the given uqzipfile.
 * The method then completes the each file record and catches any error given by
 * a child.
 *
 * 	params: A Parameters struct detailing the command line arguments.
 * 	compressdata: A incomplete CompressionData struct which initially
 * contains information limited to the information in params.
 *
 * 	returns: Returns a CompressionData struct with completed all information
 * about each file record.
 */
CompressionData sequential_file_data(
        Parameters params, CompressionData compressdata)
{
    for (int i = 0; i < (int)params.numFiles; i++) {
        while (!sigintOccurred) {
            compressdata.filescompressed++;
            uint32_t datalength = 0;
            char* filename = params.filenames[i];
            char** args
                    = get_method_arguments(params.compressionmethod, filename);
            int fd[2];
            pipe(fd);
            pid_t pid = fork();
            if (pid == 0) {
                suppress_stderr();
                close(fd[0]);
                dup2(fd[1], STDOUT_FILENO);
                close(fd[1]);
                execvp(args[0], args);
                kill(getpid(), SIGUSR1);
            } else {
                close(fd[1]);
                char* zipfilename = params.uqzipFileName;
                int zipfd = open(zipfilename, O_WRONLY, FILE_PERMISSIONS);
                compressdata.offset[i] = lseek(zipfd, 0, SEEK_END);
                initialise_file_record(zipfd, compressdata.filenamelength[i],
                        compressdata.filebasenames[i]);
                char buffer[BUFFER_SIZE];
                int bytesRead;
                while ((bytesRead = read(fd[0], buffer, sizeof(buffer))) > 0) {
                    write(zipfd, buffer, bytesRead);
                    datalength += bytesRead;
                }
                close(fd[0]);
                compressdata.datalength[i] = datalength;
                update_data_length(zipfd, compressdata.filenamelength[i],
                        compressdata.datalength[i]);
                compressdata.padding[i] = write_padding(
                        zipfd, compressdata.filenamelength[i], datalength);
                int status;

                close(zipfd);
                waitpid(pid, &status, 0);
                status_check(status, params, compressdata, i);
            }
            free(args);
            break;
        }
    }

    return compressdata;
}

/* status_check()
 * --------------
 * 	When given a status, method checks if status dictates an error message
 * and exit codeand does if so.
 *
 * 	status: An integer for the given status.
 * 	compressdata: The complete CompressionData struct returnd by
 *      sequential_file_data().
 *      params: A Parameters struct containing relevent information about the
 *      command line arguments.
 */
void status_check(int status, Parameters params, CompressionData compressdata,
        int filenum)
{
    if (WIFSIGNALED(status) && WTERMSIG(status) == SIGUSR1) {
        fprintf(stderr, "uqzip: Can't execute command \"%s\"\n",
                params.compressionmethod[0]);
        remove(params.uqzipFileName);
        exit(COMMAND_ERROR);
    } else if (WEXITSTATUS(status) != 0) {
        fprintf(stderr, "uqzip: Command \"%s\" failed for filename \"%s\"\n",
                params.compressionmethod[0],
                compressdata.filebasenames[filenum]);
        remove(params.uqzipFileName);
        exit(COMMAND_FILE_ERROR);
    }
}

/* supress_stderr()
 * ----------------
 * 	Method uses file descriptors to supress the stderr of the process
 * 	from which it was called.
 */
void suppress_stderr()
{
    int nullfd = open("/dev/null", O_WRONLY);
    dup2(nullfd, STDERR_FILENO);
    close(nullfd);
}

/* initialise_file_record()
 * ------------------------
 * 	Method initialises the file record for a given filename by writting the
 * 	appropriate file name and length. Additionally a placeholder for the
 * datalength is created.
 *
 * 	zipfd: A file descriptor integer to the given uqzip file.
 * 	filenamelength: A 8-bit unsigned integer for the length of the file
 * 	name.
 * 	filename: The string of the uqzip file name.
 */
void initialise_file_record(int zipfd, uint8_t filenamelength, char* filename)
{
    // Placeholder for datasize
    uint32_t placeholder = 0;
    write(zipfd, &(placeholder), sizeof(uint32_t));
    // Write filename length
    write(zipfd, &(filenamelength), sizeof(uint8_t));
    // Write filename
    write(zipfd, filename, sizeof(char) * filenamelength);
}

/* update_data_length()
 * --------------------
 * 	When called, method updates the placeholders in the file records with
 * the relevent data length.
 *
 * 	zipfd: A file ID relevent to the file already open in caller method.
 * 	basenamelength: The size of the basenamelength for filerecord.
 * 	datalength: The datalength of the relevent file.
 */
void update_data_length(int zipfd, uint8_t basenamelength, uint32_t datalength)
{
    int offset = -FILERECORD_BYTES - (int)basenamelength - (int)datalength;
    lseek(zipfd, offset, SEEK_END);
    write(zipfd, &(datalength), sizeof(uint32_t));
}

/* update_header()
 * ---------------
 * 	When called, method updates the uqzip header with relevent file
 * 	record offsets for each file.
 *
 * 	compressdata: The complete CompressionData struct returnd by
 * 	sequential_file_data().
 *	params: A Parameters struct containing relevent information about the
 *      command line arguments.
 */
void update_header(CompressionData compressdata, Parameters params)
{
    uint32_t numfiles = params.numFiles;
    int zipfd = open(params.uqzipFileName, O_WRONLY, FILE_PERMISSIONS);
    uint32_t offsets[numfiles];
    for (int i = 0; i < (int)numfiles; i++) {
        offsets[i] = compressdata.offset[i];
    }
    lseek(zipfd, HEADER_BYTES, SEEK_SET);
    write(zipfd, &(offsets), sizeof(uint32_t) * numfiles);
    close(zipfd);
}

/* write_padding()
 * ---------------
 * 	Method appends to the file the relevent padding in order to
 * 	for the file length to be divisible by four. Additionally the
 * 	padding bytesize is returned.
 *
 * 	zipfd: A file ID relevent to the file already open in caller method.
 * 	filenamelength: The size of the basenamelength for filerecord.
 * 	datalength: The datalength of the relevent file.
 *
 * 	returns: An integer representing the number of bytes of the padding. *
 */
int write_padding(int zipfd, int filenamelength, int datalength)
{
    int paddingbytenum = 0;

    while ((FILERECORD_BYTES + filenamelength + datalength + paddingbytenum)
                    % PADDING_FACTOR
            != 0) {
        paddingbytenum++;
    }
    char* array = malloc(paddingbytenum * sizeof(char));
    void* padding = memset(array, 0, paddingbytenum);
    lseek(zipfd, 0, SEEK_END);
    write(zipfd, padding, paddingbytenum);
    return paddingbytenum;
}

/* get_method_arguments()
 * ----------------------
 * 	When called, the method creates and returns an array of strings
 * 	detailing the command line argument to pass for a given compression
 * 	method.
 *
 * 	method[]: The compression method commands.
 * 	filename: The filename on which to conduct the operations.
 */
char** get_method_arguments(const char* const method[], char* filename)
{
    int numargs = 0;
    char** args;
    while (method[numargs] != NULL) {
        numargs++;
    }

    if (filename == NULL) {
        args = malloc(numargs * sizeof(char*));
        for (int i = 0; i < numargs; i++) {
            args[i] = (char*)method[i];
        }
    } else {

        args = malloc((numargs + 2) * sizeof(char*));

        for (int i = 0; i < numargs; i++) {
            args[i] = (char*)method[i];
        }

        args[numargs] = filename;
        args[numargs + 1] = NULL;
    }
    return args;
}

/* initialise_compressdata()
 * ----------------
 * 	Method initialises CompressionData struct with relevent information
 * 	given by params(). For arguments which cannot yet be filled,
 * placeholders are given.
 *
 * 	params: A Parameters struct containing relevent information about the
 *      command line arguments.
 *
 *      returns: An initilised CompressionData struct with information from
 * params.
 */
CompressionData initialise_compressdata(Parameters params)
{
    char** basenames = file_basenames(params.filenames, params.numFiles);
    uint8_t* filenamelengths = string_array_lengths(basenames, params.numFiles);
    uint32_t* datalengths = malloc(params.numFiles * sizeof(uint32_t));
    int* padding = malloc(params.numFiles * sizeof(int));
    int* offset = malloc(params.numFiles * sizeof(uint32_t));
    for (int i = 0; i < (int)params.numFiles; i++) {
        datalengths[i] = 0;
        offset[i] = 0;
    }

    CompressionData compressdata = {
            .numfiles = params.numFiles,
            .datalength = datalengths,
            .filenamelength = filenamelengths,
            .filebasenames = basenames,
            .zipfilename = params.uqzipFileName,
            .padding = padding,
            .offset = offset,
            .filescompressed = 0,
    };

    return compressdata;
}

/* string_array_lengths()
 * ----------------------
 * 	Method iterates through strings creating a new list of integers
 * 	with respective string lengths.
 *
 * 	strings: The list of strings with lengths to find.
 * 	numfiles: The number of arguments in strings.
 *
 * 	returns: A list of unsigned 8-bit integers.
 */
uint8_t* string_array_lengths(char** strings, int numfiles)
{
    uint8_t* stringlengths = malloc(sizeof(int) * numfiles);
    for (int i = 0; i < numfiles; i++) {
        stringlengths[i] = strlen(strings[i]);
    }
    return stringlengths;
}

/* file_basenames()
 * ----------------
 * 	Method iterates through the filenames and constructs a
 * 	new array of strings with their respective basenames
 * 	which is then returned.
 *
 * 	filenames: An array of filenames for which to find
 * 	the basenames.
 * 	numfiles: The number of files in filenames.
 */
char** file_basenames(char** filenames, int numfiles)
{
    char** filebasenames = malloc(sizeof(char*) * numfiles);

    for (int i = 0; i < numfiles; i++) {
        char* filename = strrchr(filenames[i], '/');
        if (filename) {
            filebasenames[i] = filename + 1;
        } else {
            filebasenames[i] = filenames[i];
        }
    }
    return filebasenames;
}

/* file_check_compression()
 * ------------------------
 * 	Method checks that a given zipfilename is a valid uqzipfile,
 * 	if it is invalid, relevent error statements are printed and the
 * 	program exits.
 *
 * 	zipfilename: A string representing the intended uqzipfile name.
 */
void file_check_compression(char* zipfilename)
{
    int zipid
            = open(zipfilename, O_WRONLY | O_CREAT | O_TRUNC, FILE_PERMISSIONS);
    if (zipid == -1) {
        fprintf(stderr, "uqzip: can't write to file \"%s\"\n", zipfilename);
        exit(ZIPWRITE_ERROR);
    }
    close(zipid);
}

/* initialise_zip()
 * ----------------
 * 	Method initialises the zip file by populating file with the
 * 	relevent file signature, method number, number of files
 * 	and finally a placeholder for the file offsets.
 *
 * 	params: A Parameters struct containing relevent information about the
 *      command line arguments.
 */
void initialise_zip(Parameters params)
{
    char* zipfilename = params.uqzipFileName;
    int zipfd
            = open(zipfilename, O_WRONLY | O_CREAT | O_TRUNC, FILE_PERMISSIONS);
    uint32_t numfiles = params.numFiles;
    // Write file signature
    lseek(zipfd, 0, SEEK_SET);
    write(zipfd, "UQZ", sizeof(char) * UQZ_SIGNATURE);

    // Write method
    write(zipfd, &(params.methodnum), sizeof(uint8_t));

    // Write number of files
    write(zipfd, &(params.numFiles), sizeof(uint32_t));

    // Make placeholders for file offsets
    int32_t* placeholder = malloc(sizeof(uint32_t) * numfiles);
    for (int i = 0; i < (int)numfiles; i++) {
        placeholder[i] = 0;
    }
    write(zipfd, placeholder, sizeof(uint32_t) * numfiles);
    close(zipfd);
}
