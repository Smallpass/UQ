#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <netdb.h>
#include <unistd.h>
#include <ctype.h>
#include <pthread.h>

// Constant game parameters struct
typedef struct {
    char* port;
    int colour;
    bool humangame;
} Parametersstruct;

// Thread file holder struct
typedef struct {
    FILE* writefile;
    FILE* readfile;
} Threadfiles;

// Total game status struct
typedef struct {
    Parametersstruct parameters;
    Threadfiles files;
    bool started;
    bool currentturn;
} Gamestatusstruct;

// Error codes enumerator
typedef enum {
    COMMAND_LINE_ERROR = 3,
    PORT_ERROR = 19,
    REGULAR_EXIT = 0,
    DISCONNECT_ERROR = 2,
} Exitcodes;

// Constant byte sizes struct
typedef enum {
    BUFFER_SIZE = 1024,
    SMALL_MOVE_LENGTH = 9,
    LONG_MOVE_LENGTH = 10,
    MOVE_COMMAND_LENGTH = 5,
    STARTED_SIZE = 8,
} Itemsizes;

// Chess peice colour enumerator
typedef enum {
    BLACK = 2,
    WHITE = 1,
} Colours;

// Define Constants
const char* const openingMessage
        = "Welcome to UQChessClient - written by s4803050";

///////////////////////////////////////////////////////////////////////////////
Parametersstruct validate_command_line(int argc, char** argv);
void command_line_error();
Parametersstruct initialise_parameters();
Gamestatusstruct initialise_gamestatus_struct(Parametersstruct parameters);
Threadfiles establish_thread_connection(Parametersstruct parameters);
void port_error(char* port);
void print_start_message(Parametersstruct parameters, FILE* writefile);
void* talk_thread_process(void* gamestatus);
void* listen_thread_process(void* gamestatus);
bool validate_server_command_timing(char command[], Gamestatusstruct* status);
bool valid_move(char command[]);
char* handle_server_output(char output[], Gamestatusstruct* gamestatus);
bool validate_command(char command[]);
bool invalid_turn_error();

///////////////////////////////////////////////////////////////////////////////

int main(int argc, char** argv)
{
    // Initialise parameters and gamestatus structs
    Parametersstruct parameters = validate_command_line(argc, argv);
    Gamestatusstruct gamestatus = initialise_gamestatus_struct(parameters);

    // creates stdin reading - server writing threads
    gamestatus.files = establish_thread_connection(parameters);

    // Declare a variable to hold the thread ID
    // Declare an attribute object
    pthread_t threadID1;
    pthread_attr_t attr1;
    pthread_attr_init(&attr1);

    pthread_t threadID2;
    pthread_attr_t attr2;
    pthread_attr_init(&attr2);

    // Create threads
    pthread_create(&threadID1, &attr1, talk_thread_process, &gamestatus);
    pthread_create(&threadID2, &attr2, listen_thread_process, &gamestatus);

    // Join threads
    pthread_join(threadID1, NULL);
    pthread_join(threadID2, NULL);
    pthread_attr_destroy(&attr1);
    pthread_attr_destroy(&attr2);
    // Flush files
    fclose(gamestatus.files.readfile);
    fclose(gamestatus.files.writefile);
    exit(REGULAR_EXIT);
}

/* listen_thread_process()
 * -----------------------
 * Method is employed as a thread process which controlls the
 * listening to the server and further handling of messages
 * for the client end. This includes writing to stdout, stderr,
 * updating the game state and handling server disconnect.
 *
 * gamestatus: A pointer to the gamestatus struct with relevent
 * game information such as parameters, file pointers, game status
 * and move status.
 *
 * returns: void* as it is a thread method
 */
void* listen_thread_process(void* gamestatus)
{
    Gamestatusstruct* status = (Gamestatusstruct*)gamestatus;
    while (1) {
        char buffer[BUFFER_SIZE];
        FILE* readfile = status->files.readfile;
        char* server = fgets(buffer, BUFFER_SIZE, readfile);
        // Checks if server sent no data.
        if (server == NULL) {
            fprintf(stderr, "uqchessclient: lost communication with server\n");
            exit(DISCONNECT_ERROR);
        }
        // Handles the server output accordingly
        char* output = handle_server_output(buffer, status);
        // Prints and flushes output
        printf(output);
        fflush(stdout);
    }
    return (void*)NULL;
}

/* handle_server_output()
 * ----------------------
 * Method handles the output from the server in order to update
 * the game state and print the board to stdout appropriately.
 * If output is not of any specified types, it is returned.
 *
 * output: The command output from the server to be analysed.
 * gamestatus: A pointer to the gamestatus struct with relevent
 * game information such as parameters, file pointers, game status
 * and move status.
 *
 * returns: The same output function from the first argument.
 */
char* handle_server_output(char output[], Gamestatusstruct* gamestatus)
{
    // check if board is output
    if (!strncmp(output, "startboard", strlen("startboard"))
            || !strncmp(output, "endboard", strlen("endboard"))) {
        return "";
    }
    if (!strncmp(output, "started", strlen("started"))) { // Check started call
        gamestatus->started = true;
        if (!strncmp(output + STARTED_SIZE, "white",
                    MOVE_COMMAND_LENGTH)) { // Check the colour of client
            gamestatus->parameters.colour = WHITE;
            gamestatus->currentturn = true;
        } else {
            gamestatus->parameters.colour = BLACK;
            gamestatus->currentturn = false;
        }
    } else if (!strncmp(output, "moved",
                       strlen("moved"))) { // Check if server moved
        gamestatus->currentturn = true;
    } else if (!strncmp(output, "ok", strlen("ok"))) { // Check move was ok
        gamestatus->currentturn = false;
    } else if (!strncmp(output, "gameover",
                       strlen("gameover"))) { // Check gameover
        gamestatus->started = false;
    }
    return output;
}

/* talk_thread_prcess()
 * --------------------
 * Method handles thread process which reads from stdin and appropriately
 * writes to the server. Method first checks for input, throwing the appropriate
 * if NULL, then it initialy validates that the command is of appropriate type.
 * Further it checks that the valid command is callable at given game status,
 * if so sending data to the server, else, an appropriate error message.
 *
 * gamestatus: A pointer to the gamestatus struct with relevent
 * game information such as parameters, file pointers, game status
 * and move status.
 *
 * returns: void* as thread process
 */
void* talk_thread_process(void* gamestatus)
{
    Gamestatusstruct* status = (Gamestatusstruct*)gamestatus;
    char buffer[BUFFER_SIZE];
    while (1) {
        // Read from stdin
        char* server = fgets(buffer, BUFFER_SIZE, stdin);
        // Checks stdin data exists
        if (server == NULL) {
            exit(REGULAR_EXIT);
        }
        // Checks command is of valid type
        if (!validate_command(buffer)) {
            continue;
        }
        // Checks command is applicable at given game status
        if (validate_server_command_timing(buffer, status)) {
        } else {
            fprintf(stderr, "Command not valid - game is not in progress\n");
            fflush(stderr);
        }
    }
    return (void*)NULL;
}

/* validate_command()
 * ------------------
 * Method validates that a passed command is of correct type to
 * send to the server. If command is incorrect, the appropriate
 * error message is sent to stderr.
 *
 * command[]: A char[] representing the command to validate.
 *
 * return: A bool, true if command is valid, false else.
 */
bool validate_command(char command[])
{
    bool valid = false;
    // Check correct type
    if (!strcmp("newgame\n", command) || !strcmp("print\n", command)
            || !strcmp("hint\n", command) || !strcmp("possible\n", command)
            || !strncmp("move ", command, MOVE_COMMAND_LENGTH)
            || !strcmp("resign\n", command) || !strcmp("quit\n", command)) {
        valid = true;
    } else {
        // Appropriate error message
        fprintf(stderr, "Command is not valid - try again\n");
        fflush(stderr);
    }
    return valid;
}

/* validate_server_command_timing()
 * --------------------------------
 * Method validates that a given valid command is executable at in the current
 * game state, specified by status. If the command is given at a correct time
 * the corresponding server understood command is sent to the server, method
 * returns false, else, it prints the appropriate error message and returns
 * false.
 *
 * command[]: The valid command string to be validate in given state.
 * status: A pointer to the gamestatus struct with relevent
 * game information such as parameters, file pointers, game status
 * and move status.
 *
 * returns: A bool, true if the command is executable, else, false. However,
 * and excpetion is made for the case where the command requires it to be
 * the clients turn, in which case, true is returned if not statisfied.
 */
bool validate_server_command_timing(char command[], Gamestatusstruct* status)
{
    FILE* writefile = status->files.writefile;
    bool started = status->started;
    bool clientturn = status->currentturn;
    if (!strcmp("newgame\n", command)) { // Check if newgame command
        print_start_message(status->parameters, writefile);
    } else if (!strcmp("print\n", command)
            && started) { // Check if print board command
        fprintf(writefile, "board\n");
    } else if (!strcmp("hint\n", command) && started) { // Check if hint command
        if (!clientturn) { // Check if clients turn
            invalid_turn_error();
        } else {
            fprintf(writefile, "hint best\n");
        }
    } else if (!strcmp("possible\n", command)
            && started) { // Check if possible hints command
        if (!clientturn) { // Check if clients turn
            invalid_turn_error();
        } else {
            fprintf(writefile, "hint all\n");
        }
    } else if (!strncmp("move ", command,
                       MOVE_COMMAND_LENGTH)) { // Check if move command
        if (valid_move(command)) { // Check if valid move
            if (!clientturn) { // Check if clients turn
                invalid_turn_error();
            } else {
                fprintf(writefile, command);
            }
        } else {
            fprintf(stderr, "Command is not valid - try again\n");
            fflush(stderr);
        }
    } else if (!strcmp("resign\n", command)
            && started) { // Check if resign command
        fprintf(writefile, "resign\n");
    } else if (!strcmp("quit\n", command)) { // Check if quit command
        exit(REGULAR_EXIT);
    } else {
        return false;
    }
    fflush(writefile);
    return true;
}

/* invalid_turn_error()
 * --------------------
 * When called, method prints the invalid turn error to stderr,
 * flushes stderr and returns true.
 *
 * Returns: A boolean for the validity of the turn. Always true.
 */
bool invalid_turn_error()
{
    fprintf(stderr, "Command is not valid - it's not your turn\n");
    fflush(stderr);
    return true;
}

/* valid_move()
 * ------------
 * Method checks that a given "move" command is followed by an
 * appropriate 4 or 5 alphanumeric characters. If so, returns
 * true, else false.
 *
 * command[]: The full string move command to be validated.
 *
 * returns: A bool, true if move command is appropriate, false else.
 */
bool valid_move(char command[])
{
    int length = (int)strlen(command);
    // Check move command is correct size
    if (length != SMALL_MOVE_LENGTH && length != LONG_MOVE_LENGTH) {
        return false;
    }
    // Checks that the ending characters are alphanumeric
    // or if new line character, ignore and end loop
    for (int i = MOVE_COMMAND_LENGTH; i < length - 1; i++) {
        if (command[i] == '\n') {

        } else if (!isalnum(command[i])) {
            return false;
        }
    }
    return true;
}

/* establish_thread_connection()
 * -----------------------------
 * Method established connection between client and server through
 * IPv4, opening read and write streams from the client to the server.
 * Additionally, the method prints the initial opening message and
 * game start message.
 *
 * parameters: A Parametersstruct with clients ends piece colour,
 * opponent type and port number.
 *
 * returns: A Threadfiles struct with write and read streams
 * to read and write from the server.
 */
Threadfiles establish_thread_connection(Parametersstruct parameters)
{
    char* port = parameters.port;
    struct addrinfo* ai = 0;
    struct addrinfo hints;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET; // IPv4
    hints.ai_socktype = SOCK_STREAM;
    int err;
    // checks that port is valid
    if ((err = getaddrinfo("localhost", port, &hints, &ai))) {
        port_error(port);
    }
    // create socket. 0 == use default stream protocol (TCP)
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        port_error(port);
    }
    if (connect(fd, ai->ai_addr, sizeof(struct sockaddr))) {
        port_error(port);
    }

    // fd is now connected
    // we want separate streams (which we can close independently)
    printf("%s\n", openingMessage);
    fflush(stdout);
    int fd2 = dup(fd);
    FILE* readfile = fdopen(fd2, "r");
    FILE* writefile = fdopen(fd, "w");
    // Sends start message to server
    print_start_message(parameters, writefile);
    // Append read and write streams to Threadfiles struct
    Threadfiles files = {
            .readfile = readfile,
            .writefile = writefile,
    };
    fflush(files.readfile);
    fflush(files.writefile);
    return files;
}

/* print_start_message()
 * ---------------------
 * Method sends the initials start game message to the server given some
 * initial game parameters and the writefile stream (server file).
 *
 * parameters: A Parametersstruct with clients ends piece colour,
 * opponent type and port number.
 *
 * writefile: A stream to the server.
 */
void print_start_message(Parametersstruct parameters, FILE* writefile)
{
    // Initialise Colours and opponent
    char* against = "computer";
    char* colour = "either";
    // Check if clients pieces are white or black
    if (parameters.colour == WHITE) {
        colour = "white";
    } else if (parameters.colour == BLACK) {
        colour = "black";
    }
    // Check if game is against human
    if (parameters.humangame) {
        against = "human";
    }
    // Send start to write stream
    fprintf(writefile, "start %s %s\n", against, colour);
    fflush(writefile);
    return;
}

/* port_error()
 * ------------
 * Method prints appropriate port error message for a given port, whilst
 * also exiting.
 */
void port_error(char* port)
{
    fprintf(stderr, "uqchessclient: unable to make connection to port \"%s\"\n",
            port);
    fflush(stderr);
    exit(PORT_ERROR);
}

/* initialise_gamestatus_struct()
 * ------------------------------
 * Method returns and initialised Gamestatusstruct, populated by the games
 * parameters, file streams, whether the game is started and the current turn.
 */
Gamestatusstruct initialise_gamestatus_struct(Parametersstruct parameters)
{
    bool currentturn = false;
    // Checks if client has first turn
    if (parameters.colour == WHITE) {
        currentturn = true;
    }
    // Creates new struct
    Gamestatusstruct gamestatus = {
            .parameters = parameters,
            .files = {
		    .writefile = NULL,
		    .readfile = NULL,
	    },
            .started = false,
            .currentturn = currentturn,
    };
    return gamestatus;
}

/* validate_command_line()
 * -----------------------
 * Method validates that all arguments on a given command line follow
 * the form ./uqchessclient port [--against human|computer] [--col black|white],
 * where the square brackets represent optional arguments. If the command line
 * is valid, the method returns a parameters struct populated with corresponding
 * port number, piece colour and opponent type data, else, it exits with
 * appropriate error code and message.
 *
 * argc: The number of arguments on the command line
 * argv: A list of strings representing the command line
 *
 * returns: A parameters struct populated with corresponding
 * port number, piece colour and opponent type data, else, it exits with
 * appropriate error code and message.
 */
Parametersstruct validate_command_line(int argc, char** argv)
{
    // Initialised parameters struct
    Parametersstruct parameters = initialise_parameters();
    // Checks command line has a minimum of two arguments
    if (argc < 2) {
        command_line_error();
    }
    // Sets first argument as the port
    parameters.port = argv[1];
    // Iterates through commandline arguments
    for (int i = 2; i < argc; i++) {
        char* arg = argv[i];
        // Checks if arguments is "--against"
        if (!strcmp("--against", arg) && (i != argc - 1)) {
            char* nextarg = argv[i + 1];
            // Checks opponent type
            if (!strcmp("human", nextarg)) {
                parameters.humangame = true;
            } else if (!strcmp("computer", nextarg)) {
                parameters.humangame = false;
            } else {
                command_line_error();
            }
            i++;
        } else if (!strcmp("--col", arg)
                && (i != argc - 1)) { // Checks if argument is "--col"
            char* nextarg = argv[i + 1];
            // Checks the colour of the client pieces
            if (!strcmp("black", nextarg)) {
                parameters.colour = BLACK;
            } else if (!strcmp("white", nextarg)) {
                parameters.colour = WHITE;
            } else {
                command_line_error();
            }
            i++;
        } else {
            command_line_error();
        }
    }
    // Checks if game is opponent is not human and colour is either
    if (!parameters.humangame && parameters.colour == 0) {
        parameters.colour = 1;
    }
    return parameters;
}

/* command_line_error()
 * --------------------
 * When called, the method prints the command line error message to
 * stderr and exits with appropriate exit code.
 */
void command_line_error()
{
    fprintf(stderr,
            "Usage: uqchessclient port [--against human|computer] [--col "
            "black|white]\n");
    fflush(stderr);
    exit(COMMAND_LINE_ERROR);
}

/* initialise_parameters()
 * -----------------------
 * Methods only purpose is to return an initialised Parametersstruct
 * with port, colour and human game being set to NUll, 0 and false
 * respectively.
 */
Parametersstruct initialise_parameters()
{
    Parametersstruct parameters = {
            .port = NULL,
            .colour = 0,
            .humangame = false,
    };
    return parameters;
}
