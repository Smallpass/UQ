#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <netdb.h>
#include <unistd.h>
#include <ctype.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdint.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <csse2310a4.h>

// Thread file holder struct
typedef struct {
    FILE* writefile;
    FILE* readfile;
} Threadfiles;

// Stockfish pipes struct
typedef struct {
    FILE* writepipe;
    FILE* readpipe;
} Stockfishpipe;

typedef struct {
    int clientnum;
    char* colour;
    char* opponent;
    Threadfiles streams;
} Clientinfo;

typedef struct {
    int serverfd;
    struct sockaddr_in addr;
} Portdata;

typedef struct {
    bool ongoing;
    char* whiteplayer;
    char* fenboard;
} Gamestate;

// Server data struct
typedef struct {
    char* port;
    Stockfishpipe stockfishpipe;
    pid_t stockfishpid;
    int numclients;
    Clientinfo** clients;
} Serverdata;

// Exit codes enumerator
typedef enum {
    NORMAL_EXIT = 0,
    COMMAND_LINE_ERROR = 16,
    PORT_ERROR = 18,
    STOCKFISH_START_ERROR = 20,
    CHESS_ENGINE_ERROR = 15,
} ErrorCodes;

// Constant byte sizes struct
typedef enum {
    BUFFER_SIZE = 1024,
    SMALL_MOVE_LENGTH = 9,
    LONG_MOVE_LENGTH = 10,
    MOVE_COMMAND_LENGTH = 5,
    STARTED_SIZE = 8,
    PORT_BUFFER_SIZE = 6,
    NUM_WELCOME_ENTRIES = 3,
    MAX_CLIENTS_ON_PORT = 10,
} Itemsizes;

// Chess peice colour enumerator
typedef enum {
    BLACK = 2,
    WHITE = 1,
} Colours;

///////////////////////////////////////////////////////////////////////////////
Serverdata validate_command_line(int argc, char** argv);
void command_line_error();
Serverdata initialise_serverdata();
void port_error(char* port);
void establish_client_connection(Serverdata* data, int fdserver);
void start_stockfish(Serverdata* data);
void stockfish_error(int writefd, int readfd);
Portdata validate_port(Serverdata* data);
void initialise_client_info(
        Serverdata* serverdata, char** welcomemessage, int clientnum);
void* computer_thread_process(void* datastruct);
void chess_engine_error();
void execute_stockfish_command(int fdwrite[], int fdread[]);
void check_stockfish_pipes(int fdwrite, int fdread);

///////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
    Serverdata data = validate_command_line(argc, argv);
    Portdata portinfo = validate_port(&data);
    start_stockfish(&data);
    fprintf(stderr, "%u\n", ntohs(portinfo.addr.sin_port));

    establish_client_connection(&data, portinfo.serverfd);

    // process_connections(fdServer);

    // fclose(data.files.readfile);
    // fclose(data.files.writefile);
    exit(NORMAL_EXIT);
}

/* establish_client_connection()
 * -----------------------------
 * When called with correctly filled serverdata* and fdserver, i.e,
 * serverdata has all data but the thread FILE*'s, the method accepts
 * client addresses from the port and subsequently creates client threads.
 * Before the threads are created, new Clientinfo structs are appended to
 * data and if the client wishes to verse a computer, the appropriate start
 * message is printed.
 *
 * data: A pointer to the servers Serverdata struct, containing relevent
 * information about the port, stockfish pipes and pid, the number of clients,
 * and the following Clientinfo of each client.
 *
 * fdserver: The integer file descriptor of the ports (servers) listening end,
 * used by the server to listen for and connect clients
 */
void establish_client_connection(Serverdata* data, int fdserver)
{
    int fd;
    struct sockaddr_in fromAddr;
    socklen_t fromAddrSize;
    char buffer[BUFFER_SIZE];
    int clientnum = 0;
    // Repeatedly accept connections and process data (capitalise)
    while (1) {
        fromAddrSize = sizeof(struct sockaddr_in);
        // Block, waiting for a new connection. (fromAddr will be populated
        // with address of client)
        fd = accept(fdserver, (struct sockaddr*)&fromAddr, &fromAddrSize);
        int fd2 = dup(fd);
        FILE* writestream = fdopen(fd, "w");
        FILE* readstream = fdopen(fd2, "r");
        // Read client welcome message
        fgets(buffer, BUFFER_SIZE, readstream);
        // Separate client message into char**
        char** welcomemessage = split_by_char(buffer, ' ', NUM_WELCOME_ENTRIES);
        // Initialise Clientinfo struct in data
        initialise_client_info(data, welcomemessage, clientnum);
        // Check if client requests computer game
        if (!strcmp(welcomemessage[1], "computer")) {
            // Print to client started message
            fprintf(writestream, "started %s", welcomemessage[2]);
            fflush(writestream);
        }
        // Store client write and read ends in data
        data->clients[clientnum]->streams.writefile = writestream;
        data->clients[clientnum]->streams.readfile = readstream;
        pthread_t threadID;
        // Start human or computer thread
        if (!strcmp(data->clients[clientnum]->opponent, "computer")) {
            pthread_create(&threadID, NULL, computer_thread_process, data);
        } else {
            // pthread_create(&threadID, NULL, computer_thread_process, data);
        }
        pthread_detach(threadID);
        // Store numclients in data and increment
        data->numclients = clientnum;
        clientnum++;
    }
}

/* computer_thread_process()
 * -------------------------
 * Thread method controls the subsequent behaviour of the client
 * thread after a computer opponent chess game has been specified.
 * After initialising relevent data, the method begins by commiting
 * the relevent communication with stockfish for the case that the client
 * has specified black or white.
 *
 * datastruct: A pointer to the (void*) of the Datastruct. Importantly,
 * at the point of thread creating, the numclients argument of the
 * struct is will be equivalent to the number of the given client.
 */
void* computer_thread_process(void* datastruct)
{
    // Typecast datastruct to Serverdata*
    Serverdata* data = (Serverdata*)datastruct;
    // Initialises variables and buffer
    int clientnum = data->numclients;
    Clientinfo* client = data->clients[clientnum];
    char command[BUFFER_SIZE];
    // Initialises threads
    // FILE* readstream = data->clients[clientnum]->streams.readfile;
    FILE* writestream = data->clients[clientnum]->streams.writefile;

    FILE* stockfishwrite = data->stockfishpipe.writepipe;
    FILE* stockfishread = data->stockfishpipe.readpipe;
    // Initialises the provided game status struct
    // StockfishGameState* stockfish = read_stockfish_d_output(stockfishread);
    // Checks if the client has picked to play back
    if (!strcmp("black", client->colour)) {
        // Communicates to start game with stockfish
        fputs("ucinewgame\n", stockfishwrite);
        fputs("isready\n", stockfishwrite);
        fflush(stockfishwrite);
        // Waits for stockfish positive reply
        while (fgets(command, BUFFER_SIZE, stockfishread) != NULL) {
            if (!strcmp("readyok\n", command)) {
                break;
            }
        }
        // Begins process by informing that stockfish conduct the first move
        fputs("position startpos\n", stockfishwrite);
        fputs("go movetime 500 depth 15\n", stockfishwrite);
        fflush(stockfishwrite);
        // Makes the stockfish move
        ChessMoves* moveslist = read_stockfish_bestmove_output(stockfishread);
        fprintf(writestream, "moved %s\n", moveslist->moves[0]);
        fflush(writestream);
    }
    return (void*)NULL;
}

/* initialise_client_info()
 * ------------------------
 * Method initialises a Clientinfo struct for an incoming client request.
 * The method utilises the information within the welcome message char**
 * and clientnum to populate the clientdata struct, appending it to data.
 * Given the case where it is not the first client, memory is realloced
 * to make space.
 *
 * data: A pointer to the servers Serverdata struct, containing relevent
 * information about the port, stockfish pipes and pid, the number of clients,
 * and the following Clientinfo of each client.
 *
 * welcomemessage: A list of strings previously separated by split_by_char()
 * with indexes 1 and 2 representing the opponent and colour of the client
 * respectively.
 *
 * clientnum: The number of clients created by the server up to the given
 * client thread.
 */
void initialise_client_info(
        Serverdata* data, char** welcomemessage, int clientnum)
{
    // Reallocates space for more clients given it is not the initial client
    if (clientnum != 0) {
        data->clients
                = realloc(data->clients, sizeof(Clientinfo*) * (clientnum + 1));
    }
    // Dynamically allocate memory for the new Clientinfo
    Clientinfo* clientdata = malloc(sizeof(Clientinfo));
    /// Initialises pointer to Clientinfo struct
    *clientdata = (Clientinfo){
	.clientnum = clientnum,
        .opponent = welcomemessage[1],
        .colour = welcomemessage[2],
        .streams = {
            .writefile = NULL,
            .readfile = NULL,
        },
    };
    // Appends Clientinfo to server data struct
    data->clients[clientnum] = clientdata;
}

/* validate_port()
 * ---------------
 * Method validates that the provided port within the Serverdata
 * struct is valid. In the case that the port is uninitialise on the command
 * line ("0"), the method uses an ephemeral port. The method utilises IPv4
 * structure to record and return a Portdata struct containing the port
 * file descriptor and address struct.
 *
 * data: A pointer to the servers Serverdata struct, containing relevent
 * information about the port, stockfish pipes and pid, the number of clients,
 * and the following Clientinfo of each client.
 *
 * returns: A Portdata struct containing the a valid listening fd for the
 * port and the corresponding addr struct.
 */
Portdata validate_port(Serverdata* data)
{
    char* port = data->port;
    struct addrinfo* ai = 0;
    struct addrinfo hints;

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_INET; // IPv4
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE; // Will allow us to bind the socket to all of
                                 // our interfaces (addresses) but only if the
                                 // first argument to getaddrinfo() is NULL)

    int err;
    if ((err = getaddrinfo(NULL, port, &hints, &ai))) {
        freeaddrinfo(ai);
        port_error(port);
    } // create a socket and bind it to ain address/port
    int serv = socket(AF_INET, SOCK_STREAM, 0); // 0 == default stream protocol
    if (bind(serv, ai->ai_addr, sizeof(struct sockaddr))) {
        port_error(port);
    }

    // Which port did we get?
    struct sockaddr_in ad;
    memset(&ad, 0, sizeof(struct sockaddr_in));
    socklen_t len = sizeof(struct sockaddr_in);
    if (getsockname(serv, (struct sockaddr*)&ad, &len)) {
        port_error(port);
    }

    if (listen(serv, MAX_CLIENTS_ON_PORT)) { // allow up to 10 connection
                                             // requests to queue
        port_error(port);
    }
    // Initialise and populate struct with serverfd and the addr struct
    Portdata portinfo = {
            .serverfd = serv,
            .addr = ad,
    };
    return portinfo;
}

/* chess_engine_error()
 * --------------------
 * When called, the method prints a terminated chess engine error
 * message to stderr and exits with appropriate error code.
 */
void chess_engine_error()
{
    fprintf(stderr, "uqchessserver: chess engine terminated\n");
    exit(CHESS_ENGINE_ERROR);
}

/* start_stockfish()
 * -----------------
 * When called, method is conducted with the purpose of appending
 * to data->stockfishpipe with the relevent read and write threads
 * of stockfish. The method achieves this by creating two pipes,
 * and forking and calling on execute_stockfish() in the child process.
 * The parent process calls check_stockfish_pipes() to check that the
 * pipes can be correctly initialised and communicated through before
 * appending the write and read ends to the serverdata struct.
 *
 * data: A pointer to the servers Serverdata struct, containing relevent
 * information about the port, stockfish pipes and pid, the number of clients,
 * and the following Clientinfo of each client.
 */
void start_stockfish(Serverdata* data)
{
    // Initialise pipes
    int fdwrite[2], fdread[2];
    pid_t pid;
    pipe(fdwrite);
    pipe(fdread);

    pid = fork();
    if (pid == 0) { // Execute stockfish
        execute_stockfish_command(fdwrite, fdread);
    } else {
        // Parent process: Communicate with Stockfish
        close(fdwrite[0]); // Close the read end of the write pipe
        close(fdread[1]); // Close the write end of the read pipe

        check_stockfish_pipes(fdwrite[1], fdread[0]);
        // At this point, Stockfish is ready, and pipes are configured
        // Save the file descriptors for further communication
        data->stockfishpipe.writepipe = fdopen(fdwrite[1], "w");
        data->stockfishpipe.readpipe = fdopen(fdread[0], "r");
    }

    return;
}

/* check_stockfish_pipes()
 * -----------------------
 * Process is intended to be called by the parent process
 * in start_stockfish() to send initial communications from
 * the thread to stockfish, and validate that the pipe remains
 * stable. In the case that the pipe fails, stockfish_error()
 * is called to free the memory and exit with appropriate
 * code and message.
 *
 * fdwrite: The pipefd that writes to stockfish.
 * fdread: The pipefd that reads from stockfish.
 */
void check_stockfish_pipes(int fdwrite, int fdread)
{
    // Send the "isready" message to Stockfish
    const char* readyMsg = "isready\n";
    if (write(fdwrite, readyMsg, strlen(readyMsg)) == -1) {
        stockfish_error(fdwrite, fdread);
    }

    // Read and wait for the "readyok" response
    char buffer[BUFFER_SIZE];
    ssize_t n;
    while ((n = read(fdread, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0'; // Null-terminate the buffer
        if (strstr(buffer, "readyok")) {
            break;
        }
    }
    // Check for stockfish read errors
    if (n == -1) {
        stockfish_error(fdwrite, fdread);
    } else if (n == 0) {
        stockfish_error(fdwrite, fdread);
    }

    // Send the "uci" message to Stockfish
    const char* uciMsg = "uci\n";
    if (write(fdwrite, uciMsg, strlen(uciMsg)) == -1) {
        stockfish_error(fdwrite, fdread);
    }

    // Wait for the "uciok" response
    memset(buffer, 0, sizeof(buffer));
    while ((n = read(fdread, buffer, sizeof(buffer) - 1)) > 0) {
        buffer[n] = '\0';
        if (strstr(buffer, "uciok")) {
            break;
        }
    }
}

/* execute_stockfish_command()
 * ---------------------------
 * Method is designed to be called from the child process of
 * start_stockfish() in order to redirect stockfish stdin and stdout
 * to the read and write threads before executing the stockfish
 * command. If stockfish fails, kill() is performed to catch the error.
 *
 * fdwrite: The write pipe of the child process to connect to
 * stockfish stdin
 * fdread: The read pipe of the child process to connect to
 * stockfish stdout
 */
void execute_stockfish_command(int fdwrite[], int fdread[])
{
    // Child process: Replace stdin and stdout with pipes
    dup2(fdwrite[0], STDIN_FILENO);
    dup2(fdread[1], STDOUT_FILENO);
    close(fdwrite[1]);
    close(fdread[0]);

    // Inherit stderr from parent (no need to change stderr)
    const char* const stockfishCommand[] = {"stockfish", NULL};
    // Execute Stockfish
    execvp(stockfishCommand[0], (char* const*)stockfishCommand);
    // If exec fails
    kill(getpid(), SIGUSR1);
}

/* stockfish_error()
 * -----------------
 * When called, the method closes both fd arguments provided, prints
 * the stockfish communication error and exits with relevent exit
 * code.
 *
 * writefd and readfd: File ids representing the write and read files
 * of the process from which the method was called to be closed.
 */
void stockfish_error(int writefd, int readfd)
{
    close(writefd);
    close(readfd);
    fprintf(stderr,
            "uqchessserver: can't start communication with chess engine\n");
    exit(STOCKFISH_START_ERROR);
}

/* port_error()
 * ------------
 * When called, method prints the unable to listen error message for a given
 * port to stderr and then exits with relevent exit code.
 *
 * port: A char* representing the port on which the process was unable
 * to listen too.
 */
void port_error(char* port)
{
    fprintf(stderr, "uqchessserver: unable to listen on port \"%s\"\n", port);
    exit(PORT_ERROR);
}

/* validate_command_line()
 * -----------------------
 * The method, when given the argc and argv parameters recieved by main
 * and the command line, validates that the command follows the
 * strict form: Usage: ./uqchessserver [--port portnumber]. In the case
 * that the command line is valid, a Serverdata struct is returned
 * containing the port found on the command line, or "0" to be used later
 * as an ephemeral port. If the command line is invalid, command_line_error()
 * is called to exit the process.
 *
 * argc: The number of arguments specified on the command line.
 * argv: A list of strings representing the command line.
 *
 */
Serverdata validate_command_line(int argc, char** argv)
{
    Serverdata data = initialise_serverdata();

    if (argc < 2) { // Check if no port specification is made
        data.port = "0";
    } else if (!strncmp(argv[1], "--port",
                       strlen("--port"))) { // Check if port is specified
        if (argc == NUM_WELCOME_ENTRIES
                && strcmp(argv[2], "")) { // Check if port is empty string
            data.port = argv[2];
        } else {
            command_line_error();
        }
    } else {
        command_line_error();
    }
    return data;
}

/* command_line_error()
 * --------------------
 * When called, the method prints to stderr the appropriate invalid
 * command line error message and exits with correct exit code.
 */
void command_line_error()
{
    fprintf(stderr, "Usage: ./uqchessserver [--port portnumber]\n");
    exit(COMMAND_LINE_ERROR);
}

/* initialise_serverdata()
 * -----------------------
 * When called, method returns a Serverdata struct with all
 * members initialised and the clients method malloced.
 */
Serverdata initialise_serverdata()
{
    Serverdata data = {
	    .port = "0",
	    .stockfishpipe = {
		    .writepipe = 0,
		    .readpipe = 0,
	    },
	    .stockfishpid = 0,
	    .numclients = 0,
	    .clients = malloc(sizeof(Clientinfo)),
    };
    return data;
}
